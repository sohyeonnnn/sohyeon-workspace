package oop2;

public interface HouseIF {
	void make();
}
