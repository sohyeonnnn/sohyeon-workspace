package baseballGame;

public class GameStart {

	public static void main(String[] args) {
		GameMenu gameMenu = new GameMenu();
		gameMenu.gameStart();

	}

}
