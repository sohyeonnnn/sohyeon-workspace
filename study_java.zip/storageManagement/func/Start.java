package func;

public class Start {

	public static void main(String[] args) {
		Manager m = new Manager();
		m.start();

	}
}
