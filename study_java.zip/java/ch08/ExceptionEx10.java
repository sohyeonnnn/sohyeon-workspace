package ch08;

public class ExceptionEx10 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		throw new Exception(); //���� �߻���Ŵ
	}

}
