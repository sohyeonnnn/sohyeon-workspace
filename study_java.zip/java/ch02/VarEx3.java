package ch02;

public class VarEx3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "Ja" + "va";
		String str = name + 8.0;

		System.out.println(name);
		System.out.println(str);
		System.out.println(7 + " " + 6);
		System.out.println(" " + 7);
		System.out.println("" + 7);
		System.out.println("" + "");
		System.out.println(7 + 7 + "");
		System.out.println("" + 7 + 7);

	}

}
