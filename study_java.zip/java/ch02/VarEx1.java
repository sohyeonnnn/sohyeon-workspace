package ch02;

public class VarEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int year = 0; 
		int age = 14;
		
		System.out.println(year);
		System.out.println(age);
		
		year=age+2000; 
		age=age+1;
		
		System.out.println(year);
		System.out.println(age);
	}

}
