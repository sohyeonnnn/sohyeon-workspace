package ch02;

public class SpecialCharEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println('\''); // \�� �տ� ���̸� ' ���
		System.out.println("abc\t123\b456");
		System.out.println('\n'); //����
		System.out.println("\"Hello\"");
		System.out.println("c:\\");

	}

}
