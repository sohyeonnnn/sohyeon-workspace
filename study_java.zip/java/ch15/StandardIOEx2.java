package ch15;

public class StandardIOEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("out: Hello World!");
		System.err.println("err: Hello World!");
	}

}
